<!-- if you select vertical Menu then comment Horizontal Menu and uncomment this-->
<?php
include 'layouts/vertical-menu-admin-employer.php';
?>

<!-- if you select Horizontal Menu then comment vertical Menu and uncomment this-->
<?php
// include 'layouts/horizontal-menu.php';
?>