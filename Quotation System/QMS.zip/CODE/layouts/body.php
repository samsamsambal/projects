<!--All Vertical Pages-->
 <body data-sidebar="dark">
